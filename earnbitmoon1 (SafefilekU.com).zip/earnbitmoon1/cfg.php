<?php

// Isi Semua Data Dibawah Dengan Benar Ya !!!
// Perhatikan Bagaimama Admin Mengisi Datanya
// Jangan Lupa Support Creator Scriptnya

//Isi USER-AGENT Sesuai Data Kalian
$user = "xxxx";

//Isi Cookie Sesuai Data Kalian
$cookie = "xxxx";

//Isi Url-Solvemedia Sesuai Data Kalian
$url_solvemedia = "xxxx";
